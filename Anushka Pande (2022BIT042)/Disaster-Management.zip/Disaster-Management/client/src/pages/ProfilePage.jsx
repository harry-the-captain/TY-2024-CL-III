

const ProfilePage = () => {
    return (
        <div >
            <h2 >User Profile</h2 >
            {/* Add user profile information here */}
        </div >
    );
};

export default ProfilePage;