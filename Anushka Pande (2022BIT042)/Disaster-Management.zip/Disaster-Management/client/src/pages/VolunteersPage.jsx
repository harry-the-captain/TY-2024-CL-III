import VolunteerComponents from "../components/VolunteerComponents.jsx";


const VolunteersPage = () => {
    return (
        <div >
            <VolunteerComponents />
        </div >
    );
};

export default VolunteersPage;