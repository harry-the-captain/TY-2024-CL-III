import React from 'react';
import { GlobalProvider } from './context/GlobalState';
import Balance from './components/Balance';
import ExpenseList from './components/ExpenseList';
import AddTransaction from './components/AddTransaction';

function App() {
    return (
        <GlobalProvider>
            <div className="container">
                <h1>Expense Tracker</h1>
                <Balance />
                <ExpenseList />
                <AddTransaction />
            </div>
        </GlobalProvider>
    );
}

export default App;