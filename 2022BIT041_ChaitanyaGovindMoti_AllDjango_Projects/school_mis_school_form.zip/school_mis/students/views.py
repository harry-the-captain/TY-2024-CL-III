from django.shortcuts import render, redirect
from .forms import StudentAdmissionForm

def student_admission(request):
    if request.method == "POST":
        form = StudentAdmissionForm(request.POST, request.FILES)  # Include FILES for image uploads
        if form.is_valid():
            student = form.save(commit=False)
            student.submitted_ip = request.META.get("REMOTE_ADDR")  # Store IP
            student.save()
            return redirect("success_page")  # Redirect after submission
    else:
        form = StudentAdmissionForm()
    
    return render(request, "students/admission_form.html", {"form": form})
