from django.urls import path
from .views import student_admission  # Ensure correct import

urlpatterns = [
    path("admission/", student_admission, name="student_admission"),
]
