from django.db import models
from django.utils.timezone import now
from django.core.exceptions import ValidationError  # ✅ Import ValidationError

from simple_history.models import HistoricalRecords

def validate_aadhaar(value):
    """Ensure Aadhaar number is exactly 12 digits."""
    if not value.isdigit() or len(value) != 12:
        raise ValidationError("Aadhaar number must be exactly 12 digits.")  # ✅ Correctly defined ValidationError

def validate_image_size(image):
    """Ensure image size is less than 1MB"""
    max_size = 1 * 1024 * 1024  # 1MB
    if image.size > max_size:
        raise ValidationError("Image size must be less than 1MB. Please upload a smaller image.")

class Student(models.Model):
    admission_number = models.CharField(max_length=20, unique=True, verbose_name="प्रवेश क्रमांक")
    full_name = models.CharField(max_length=100, verbose_name="पूर्ण नाव")

    full_name_marathi = models.CharField(max_length=100, verbose_name="पूर्ण नाव (मराठी)")
    passport_photo = models.ImageField(
        upload_to="student_photos/",
        blank=True, null=True,
        validators=[validate_image_size],
        verbose_name="Student Passport Photo"
    )

    gender = models.CharField(
        max_length=10,
        choices=[('Male', 'पुरुष'), ('Female', 'स्त्री'), ('Other', 'इतर')],
        verbose_name="लिंग"
    )
    dob = models.DateField(verbose_name="जन्मतारीख")
    age = models.CharField(max_length=20, verbose_name="वर्ष, महिने, दिवस")
    birthplace = models.CharField(max_length=100, verbose_name="जन्मस्थान")  # Corrected field name
    nationality = models.CharField(max_length=50, verbose_name="राष्ट्रीयत्व")
    religion = models.CharField(max_length=50, verbose_name="धर्म")
    caste = models.CharField(max_length=50, verbose_name="जात")
    sub_caste = models.CharField(max_length=50, verbose_name="उपजात")
    aadhaar_number = models.CharField(
        max_length=12,
        unique=True,
        verbose_name="आधार क्रमांक",
        validators=[validate_aadhaar]  # ✅ Add the validator
    )
    admission_date = models.DateField(verbose_name="प्रवेश दिनांक")
    previous_school = models.CharField(max_length=100, blank=True, verbose_name="मागील शाळेचे नाव")
    class_admitted_to = models.CharField(max_length=20, verbose_name="प्रवेश वर्ग")
    student_unique_id = models.CharField(max_length=50, blank=True, verbose_name="विद्यार्थी सर्ट ID")
    birth_registration_number = models.CharField(max_length=50, verbose_name="जन्म नोंदणी क्रमांक")
    registration_number = models.CharField(max_length=50, verbose_name="नोंदणी क्रमांक")

    # New Features
    created_at = models.DateTimeField(auto_now_add=True)  # Stores submission timestamp
    updated_at = models.DateTimeField(auto_now=True)  # Stores last modification timestamp
    submitted_ip = models.GenericIPAddressField(null=True, blank=True)  # Stores user IP
    history = HistoricalRecords()  # Enables modification tracking

    def save(self, *args, **kwargs):
        if not self.admission_number:
            self.admission_number = self.generate_admission_number()
        super().save(*args, **kwargs)

    def generate_admission_number(self):
        last_student = Student.objects.order_by('-id').first()
        next_id = last_student.id + 1 if last_student else 1
        return f"2025-{next_id:03d}"

    def __str__(self):
        return self.full_name

class Address(models.Model):
    student = models.OneToOneField(Student, on_delete=models.CASCADE, related_name="address")  # Added `related_name`
    current_address = models.TextField(verbose_name="सध्याचा पत्ता")
    permanent_address = models.TextField(verbose_name="स्थायी पत्ता")
    district = models.CharField(max_length=50, verbose_name="तालुका")
    state = models.CharField(max_length=50, verbose_name="राज्य")
    pincode = models.CharField(max_length=10, verbose_name="पिन कोड")

    def __str__(self):
        return f"{self.student.full_name} - {self.permanent_address}"



class ParentGuardian(models.Model):
    student = models.OneToOneField(Student, on_delete=models.CASCADE)
    passport_photo = models.ImageField(
        upload_to="parent_guardian_photos/",
        blank=True, null=True,
        validators=[validate_image_size],
        verbose_name="Parent/Guardian Passport Photo"
    )
    # Father's details
    father_name = models.CharField(max_length=100, verbose_name="वडिलांचे संपूर्ण नाव")
    father_name_marathi = models.CharField(max_length=100, verbose_name="वडिलांचे संपूर्ण नाव (मराठीत)", blank=True, null=True)
    father_education = models.CharField(max_length=100, verbose_name="वडिलांचे शिक्षण")
    father_occupation = models.CharField(max_length=100, verbose_name="वडिलांचा व्यवसाय")
    father_income = models.IntegerField(verbose_name="वडिलांचे वार्षिक उत्पन्न")

    # Mother's details
    mother_name = models.CharField(max_length=100, verbose_name="आईचे संपूर्ण नाव")
    mother_name_marathi = models.CharField(max_length=100, verbose_name="आईचे संपूर्ण नाव (मराठीत)", blank=True, null=True)
    mother_education = models.CharField(max_length=100, verbose_name="आईचे शिक्षण")
    mother_occupation = models.CharField(max_length=100, verbose_name="आईचा व्यवसाय")
    mother_income = models.IntegerField(verbose_name="आईचे वार्षिक उत्पन्न")

    # Guardian (if applicable)
    guardian_name = models.CharField(max_length=100, verbose_name="पालकाचे नाव", blank=True, null=True)
    guardian_occupation = models.CharField(max_length=100, verbose_name="पालकाचा व्यवसाय", blank=True, null=True)

    # Financial details
    annual_income = models.IntegerField(verbose_name="वार्षिक उत्पन्न")
    bank_name = models.CharField(max_length=100, verbose_name="बँकेचे नाव")
    bank_branch = models.CharField(max_length=100, verbose_name="शाखा")
    account_number = models.CharField(max_length=20, verbose_name="बँक खाते क्रमांक")
    ifsc_code = models.CharField(max_length=15, verbose_name="IFSC कोड")

    def __str__(self):
        return f"{self.student.full_name} - {self.father_name}"
class FamilyMember(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    member_name = models.CharField(max_length=100, verbose_name="सदस्याचे नाव")
    relationship = models.CharField(max_length=50, verbose_name="नाते")
    gender = models.CharField(max_length=10, choices=[('Male', 'पुरुष'), ('Female', 'स्त्री'), ('Other', 'इतर')], verbose_name="लिंग")
    education = models.CharField(max_length=100, verbose_name="शिक्षण")
    occupation = models.CharField(max_length=100, verbose_name="व्यवसाय")
    aadhaar_number = models.CharField(max_length=12, verbose_name="आधार क्रमांक")
    contact_number = models.CharField(max_length=15, verbose_name="संपर्क क्रमांक")

    def __str__(self):
        return f"{self.student.full_name} - {self.member_name}"

class Scholarship(models.Model):
    student = models.OneToOneField(Student, on_delete=models.CASCADE)
    free_bicycle = models.BooleanField(default=False, verbose_name="मोफत सायकल")
    free_books = models.BooleanField(default=False, verbose_name="मोफत पुस्तके")
    uniform_grant = models.BooleanField(default=False, verbose_name="उपस्थिती भत्ता")
    tribal_scholarship = models.BooleanField(default=False, verbose_name="आदिवासी शिष्यवृत्ती")
    backward_class_scholarship = models.BooleanField(default=False, verbose_name="अल्पसंख्याक शिष्यवृत्ती")
    promotion_grant = models.BooleanField(default=False, verbose_name="प्रोत्साहन भत्ता")
    transport_grant = models.BooleanField(default=False, verbose_name="वाहन भत्ता")

    def __str__(self):
        return self.student.full_name

class Documents(models.Model):
    student = models.OneToOneField(Student, on_delete=models.CASCADE)
    birth_certificate = models.BooleanField(default=False, verbose_name="जन्म प्रमाणपत्र")
    aadhaar_card = models.BooleanField(default=False, verbose_name="आधार कार्ड")
    caste_certificate = models.BooleanField(default=False, verbose_name="जात प्रमाणपत्र")
    disability_certificate = models.BooleanField(default=False, verbose_name="अपंगत्व प्रमाणपत्र")
    parent_bank_passbook = models.BooleanField(default=False, verbose_name="पालक बँक पासबुक")

    def __str__(self):
        return self.student.full_name

class FormTracking(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    submitted_by = models.CharField(max_length=100, verbose_name="फॉर्म भरलेला वापरकर्ता")
    user_ip = models.GenericIPAddressField(verbose_name="IP पत्ता")
    submission_time = models.DateTimeField(auto_now_add=True, verbose_name="सादर करण्याची वेळ")
    modified_time = models.DateTimeField(auto_now=True, verbose_name="अद्यतन वेळ")

    def __str__(self):
        return f"{self.student.full_name} - {self.submitted_by}"
