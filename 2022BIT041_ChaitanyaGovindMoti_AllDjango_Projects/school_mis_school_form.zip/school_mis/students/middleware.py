from django.utils.timezone import now
from students.models import Student  # Import the Student model

class CaptureUserIPMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if request.user.is_authenticated and request.method == "POST":
            student = Student.objects.filter(full_name=request.user.get_full_name()).first()

            if student:
                student.submitted_ip = request.META.get('REMOTE_ADDR')
                student.save()
        return response
