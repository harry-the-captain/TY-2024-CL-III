from django import forms
from .models import Student
import re

def validate_image_size(image):
    """Ensure image size is less than 1MB"""
    max_size = 1 * 1024 * 1024  # 1MB
    if image and image.size > max_size:
        raise forms.ValidationError("Image size must be less than 1MB. Please upload a smaller image.")

class StudentAdmissionForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = "__all__"  # Or specify required fields

    def clean_aadhaar_number(self):
        aadhaar = self.cleaned_data.get("aadhaar_number")
        if not re.match(r"^\d{12}$", aadhaar):
            raise forms.ValidationError("Aadhaar number must be exactly 12 digits.")
        return aadhaar

    def clean_passport_photo(self):
        photo = self.cleaned_data.get("passport_photo")
        if photo:
            if photo.size > 1024 * 1024:  # 1 MB limit
                raise forms.ValidationError("Passport photo must be less than 1 MB.")
        return photo

    def clean_parent_guardian_photo(self):
        photo = self.cleaned_data.get("parent_guardian_photo")
        if photo:
            validate_image_size(photo)
        return photo
