from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.core.exceptions import ValidationError
from django.utils.html import format_html
from .models import (
    Student, ParentGuardian, FamilyMember, Address, Scholarship, Documents, FormTracking
)

# Inline Admin for Related Models
class FamilyMemberInline(admin.TabularInline):
    model = FamilyMember
    extra = 1  # Allows adding family members directly from student profile

@admin.register(ParentGuardian)
class ParentGuardianAdmin(admin.ModelAdmin):
    list_display = ("student", "father_name", "mother_name", "father_occupation", "mother_occupation", "father_income", "mother_income")
    search_fields = ("student__full_name", "father_name", "mother_name", "father_occupation", "mother_occupation")

    fieldsets = (
        (_("Father's Information"), {
            'fields': ("father_name", "father_name_marathi", "father_occupation", "father_income")
        }),
        (_("Mother's Information"), {
            'fields': ("mother_name", "mother_name_marathi", "mother_occupation", "mother_income")
        }),
        (_("Guardian (if applicable)"), {
            'fields': ("guardian_name", "guardian_occupation")
        }),
        (_("Financial Information"), {
            'fields': ("annual_income", "bank_name", "bank_branch", "account_number", "ifsc_code")
        }),
    )

class ScholarshipAdmin(admin.ModelAdmin):
    list_display = ("student", "free_bicycle", "free_books", "uniform_grant", "tribal_scholarship", "backward_class_scholarship", "promotion_grant", "transport_grant")
    list_filter = ("free_bicycle", "free_books", "uniform_grant", "tribal_scholarship", "backward_class_scholarship", "promotion_grant", "transport_grant")

    search_fields = ("student__full_name", "scholarship_scheme")

class DocumentsAdmin(admin.ModelAdmin):
    list_display = ("student", "birth_certificate", "aadhaar_card", "caste_certificate", "disability_certificate")
    list_filter = ("birth_certificate", "aadhaar_card", "caste_certificate", "disability_certificate")
    search_fields = ("student__full_name",)


class FormTrackingAdmin(admin.ModelAdmin):
    list_display = ("student", "submitted_by", "user_ip", "submission_time", "modified_time")
    list_filter = ("submission_time", "modified_time")
    search_fields = ("student__full_name", "submitted_by", "user_ip")

class AddressAdmin(admin.ModelAdmin):
    list_display = ("student", "current_address", "permanent_address", "district", "state", "pincode")
    search_fields = ("student__full_name", "district", "state", "pincode")

class StudentAdmin(admin.ModelAdmin):
    list_display = ("admission_number", "full_name", "class_admitted_to", "dob", "aadhaar_number", "passport_photo_display")
    search_fields = ("full_name", "admission_number", "aadhaar_number")
    list_filter = ("class_admitted_to", "dob")

    fieldsets = (
        (_("Personal Information"), {
            'fields': ("admission_number", "full_name", "full_name_marathi", "dob", "gender", "birthplace", "nationality", "religion", "caste", "aadhaar_number", "passport_photo")
        }),
        (_("Additional Information"), {
            'fields': ("sub_caste",)
        }),
        (_("Admission Details"), {
            'fields': ("admission_date", "previous_school", "class_admitted_to")
        }),
    )

    def passport_photo_display(self, obj):
        """Display passport photo as an image preview in the Django Admin panel."""
        if obj.passport_photo:
            return format_html('<img src="{}" width="60" height="75" style="border-radius:5px;"/>', obj.passport_photo.url)
        return "No Image"

    passport_photo_display.short_description = "Passport Photo"
    inlines = [FamilyMemberInline]
def save_model(self, request, obj, form, change):
        """Validate Aadhaar number before saving."""
        if not obj.aadhaar_number.isdigit() or len(obj.aadhaar_number) != 12:
            raise ValidationError("Aadhaar number must be exactly 12 digits.")
        super().save_model(request, obj, form, change)
# Register models with custom admin settings
admin.site.register(Student, StudentAdmin)
#admin.site.register(ParentGuardian, ParentGuardianAdmin)
admin.site.register(FamilyMember)
admin.site.register(Scholarship, ScholarshipAdmin)
admin.site.register(Documents, DocumentsAdmin)
admin.site.register(Address, AddressAdmin)
admin.site.register(FormTracking, FormTrackingAdmin)

# Customizing Admin Site Header and Titles
admin.site.site_header = "School Management System Admin"
admin.site.site_title = "School Management Admin"
admin.site.index_title = "Welcome to the School MIS"
