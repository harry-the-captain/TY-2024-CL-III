from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .google_sheets import fetch_google_sheet_data


@login_required
def dashboard(request):
    try:
        spreadsheet_id = '1qcYZFyRCIjAKvr2UBMCptYkar3a8LFwLHnNLQYgok6M'
        range_name = 'Flex45A!A1:Z100'
        data = fetch_google_sheet_data(spreadsheet_id, range_name)

        if not data or len(data) < 2:
            return render(request, 'dashboard.html', {'error_message': 'No data available.'})

        field_names = data[0]
        field_values = data[1:]

        # Admin View - Show all data
        if request.user.is_superuser:
            filtered_data = field_values
        else:
            # User View - Filter by Email
            user_email = request.user.email
            filtered_data = [row for row in field_values if user_email in row]

        return render(request, 'dashboard.html', {
            'field_names': field_names,
            'field_values': filtered_data,
        })
    except Exception as e:
        return render(request, 'dashboard.html', {'error_message': str(e)})

# Google Sheet Data View
@login_required
def sheet_data_view(request):
    try:
        spreadsheet_id = '1qcYZFyRCIjAKvr2UBMCptYkar3a8LFwLHnNLQYgok6M'
        range_name = 'Flex45A!A1:Z100'
        data = fetch_google_sheet_data(spreadsheet_id, range_name)
        
        context = {'data': data} if data else {'error_message': 'No data available.'}
        return render(request, 'leave_management/google_sheet_data.html', context)

    except Exception as e:
        return render(request, 'leave_management/google_sheet_data.html', {'error_message': f"Error: {str(e)}"})

# Logout View
def logout_view(request):
    return redirect('/accounts/logout/')
