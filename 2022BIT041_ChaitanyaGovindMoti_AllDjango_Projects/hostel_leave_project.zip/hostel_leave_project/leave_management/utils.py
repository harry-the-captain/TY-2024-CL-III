import gspread
from google.oauth2.service_account import Credentials

def fetch_google_sheet_data(sheet_url):
    try:
        scope = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive']
        creds = Credentials.from_service_account_file('credentials.json', scopes=scope)
        client = gspread.authorize(creds)

        sheet = client.open_by_url(sheet_url)
        worksheet = sheet.get_worksheet(0)
        data = worksheet.get_all_records()
        return data
    except Exception as e:
        print(f"Error fetching data: {e}")
        return []
