from google.oauth2 import service_account
from googleapiclient.discovery import build

def fetch_google_sheet_data(spreadsheet_id, range_name):
    try:
        # Load credentials from service account
        creds = service_account.Credentials.from_service_account_file(
            'credentials.json', scopes=['https://www.googleapis.com/auth/spreadsheets.readonly']
        )

        # Connect to Google Sheets API
        service = build('sheets', 'v4', credentials=creds)
        sheet = service.spreadsheets()

        # Get data from Google Sheets
        result = sheet.values().get(spreadsheetId=spreadsheet_id, range=range_name).execute()
        data = result.get('values', [])

        return data
    except Exception as e:
        print(f"Error fetching data from Google Sheets: {e}")
        return []
