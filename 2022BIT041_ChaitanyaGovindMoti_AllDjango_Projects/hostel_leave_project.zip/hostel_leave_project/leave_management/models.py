from django.db import models
from django.contrib.auth import get_user_model

# User = get_user_model()

# class LeaveApplication(models.Model):
#     # date = models.DateField()
#     # time = models.TimeField()
#     # phone_no = models.CharField(max_length=15)
#     # phone_name = models.CharField(max_length=100)
#     # student_name = models.CharField(max_length=100)
#     # branch = models.CharField(max_length=50)
#     # acyr = models.CharField(max_length=10)
#     # gender = models.CharField(max_length=10)
#     # sggsemail = models.EmailField()
#     # programid = models.CharField(max_length=20)
#     # yearid = models.CharField(max_length=10)
#     # semid = models.CharField(max_length=10)
#     # your_photo = models.ImageField(upload_to='photos/', blank=True, null=True)
#     # hostel_name = models.CharField(max_length=100)
#     # floor_number = models.PositiveIntegerField()
#     # room_no = models.CharField(max_length=10)
#     # roommate_details = models.TextField(blank=True, null=True)
#     # leave_date = models.DateField()
#     # leave_time = models.TimeField()
#     # current_location = models.CharField(max_length=255)
#     # return_date = models.DateField()
#     # return_time = models.TimeField()
#     # application_hardcopy = models.BooleanField(default=False)
#     # parent_mobile_no = models.CharField(max_length=15)
#     # destination_address = models.TextField()
#     # reason_for_leave = models.TextField()
#     # photo = models.ImageField(upload_to='photos/', blank=True, null=True)
    
#     # # Additional Fields
#     # user_created = models.DateTimeField(auto_now_add=True)
#     # user_updated = models.DateTimeField(auto_now=True)
#     # user = models.ForeignKey(User, on_delete=models.CASCADE)
#     date = models.CharField(max_length=20)  # Storing as text
#     time = models.CharField(max_length=20)  # Storing as text
#     phone_no = models.CharField(max_length=15)
#     phone_name = models.CharField(max_length=100)
#     student_name = models.CharField(max_length=100)
#     branch = models.CharField(max_length=50)
#     acyr = models.CharField(max_length=10)
#     gender = models.CharField(max_length=10)
#     sggsemail = models.EmailField()
#     programid = models.CharField(max_length=20)
#     yearid = models.CharField(max_length=10)
#     semid = models.CharField(max_length=10)
#     your_photo = models.ImageField(upload_to='photos/', blank=True, null=True)
#     hostel_name = models.CharField(max_length=100)
#     floor_number = models.CharField(max_length=10)  # Changed to text to allow flexibility
#     room_no = models.CharField(max_length=10)
#     roommate_details = models.TextField(blank=True, null=True)
#     leave_date = models.CharField(max_length=20)  # Storing as text
#     leave_time = models.CharField(max_length=20)  # Storing as text
#     current_location = models.CharField(max_length=255)
#     return_date = models.CharField(max_length=20)  # Storing as text
#     return_time = models.CharField(max_length=20)  # Storing as text
#     application_hardcopy = models.CharField(max_length=10)  # Storing as text (True/False or Yes/No)
#     parent_mobile_no = models.CharField(max_length=15)
#     destination_address = models.TextField()
#     reason_for_leave = models.TextField()
#     photo = models.ImageField(upload_to='photos/', blank=True, null=True)

#     # Additional Fields
#     user_created = models.DateTimeField(auto_now_add=True)
#     user_updated = models.DateTimeField(auto_now=True)
#     user = models.ForeignKey(User, on_delete=models.CASCADE)
#     def __str__(self):
#         return f'{self.student_name} - {self.leave_date}'
