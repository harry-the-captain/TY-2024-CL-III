from django.urls import path
from .views import dashboard, sheet_data_view

urlpatterns = [
    path('', dashboard, name='dashboard'),  # Serve Dashboard as Home Page
    path('dashboard/', dashboard, name='dashboard'),  # Dashboard for users
    path('sheet-data/', sheet_data_view, name='sheet_data'),
]
