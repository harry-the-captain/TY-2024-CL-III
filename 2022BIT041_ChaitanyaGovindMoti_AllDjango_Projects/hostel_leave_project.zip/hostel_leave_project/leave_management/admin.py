# from django.contrib import admin
# from .models import LeaveApplication
# from import_export import resources
# from import_export.admin import ExportMixin, ImportExportModelAdmin,ImportExportMixin

# # Create a Resource for Import-Export
# class LeaveApplicationResource(resources.ModelResource):
#     class Meta:
#         model = LeaveApplication

# # Admin Configuration with ImportExportMixin
# @admin.register(LeaveApplication)
# class LeaveApplicationAdmin(ImportExportMixin, admin.ModelAdmin):
#     resource_class = LeaveApplicationResource
#     list_display = [field.name for field in LeaveApplication._meta.fields]
#     search_fields = ('student_name', 'phone_no', 'sggsemail', 'hostel_name', 'room_no')
#     list_filter = ('leave_date', 'hostel_name', 'gender', 'branch')
#     readonly_fields = ('user_created', 'user_updated', 'user')

#     def save_model(self, request, obj, form, change):
#         obj.user = request.user
#         super().save_model(request, obj, form, change)


