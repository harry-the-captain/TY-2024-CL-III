from django.contrib import admin
from django.contrib.auth.models import User, Group, Permission
from import_export.admin import ImportExportModelAdmin
from import_export import resources
from django.contrib.auth.hashers import make_password
from .models import (
    SchoolClass, Subject, Teacher, ExamPattern, Student,
    Enrollment, FeeType, Fee, Exam, Result
)
from data_wizard import register

# Register models for bulk import (if using data_wizard)
for model in [SchoolClass, Subject, Teacher, ExamPattern, Student, Enrollment, FeeType, Fee, Exam, Result]:
    register(model)

# Unregister the default User model if already registered
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass  # Ignore if User is not registered yet

# Bulk User Import using Django Import-Export
class UserResource(resources.ModelResource):
    class Meta:
        model = User
        fields = ("id", "username", "email", "first_name", "last_name", "is_staff", "is_superuser", "password")

    def before_import_row(self, row, **kwargs):
        row["password"] = make_password(row["password"])  # Hash password before saving

class GroupResource(resources.ModelResource):
    class Meta:
        model = Group
        fields = ("id", "name")

    def before_import_row(self, row, **kwargs):
        group, created = Group.objects.get_or_create(name=row["name"])
        permissions = row["permissions"].split(",") if row["permissions"] else []
        
        for perm in permissions:
            perm_obj = Permission.objects.filter(codename=perm.strip()).first()
            if perm_obj:
                group.permissions.add(perm_obj)

# Unregister Group model before registering a custom admin
try:
    admin.site.unregister(Group)
except admin.sites.NotRegistered:
    pass  # Ignore if Group is not registered yet

@admin.register(Group)
class GroupAdmin(ImportExportModelAdmin):
    resource_class = GroupResource
    list_display = ("name",)
    search_fields = ("name",)

@admin.register(User)
class UserAdmin(ImportExportModelAdmin):
    resource_class = UserResource
    list_display = ("username", "email", "is_staff", "is_superuser")
    search_fields = ("username", "email")

# Base class for all Admin models
class BaseAdmin(ImportExportModelAdmin):
    list_per_page = 20

    def save_model(self, request, obj, form, change):
        if hasattr(obj, 'user') and not obj.user:
            obj.user = request.user
        super().save_model(request, obj, form, change)

# Admin classes for different models
@admin.register(SchoolClass)
class SchoolClassAdmin(BaseAdmin):
    list_display = ('name', 'division', 'created', 'updated', 'user')
    search_fields = ('name', 'division')
    ordering = ('name',)

@admin.register(Subject)
class SubjectAdmin(BaseAdmin):
    list_display = ('name', 'school_class', 'created', 'updated', 'user')
    search_fields = ('name', 'school_class__name')
    ordering = ('name',)

@admin.register(Teacher)
class TeacherAdmin(BaseAdmin):
    list_display = ('name', 'created', 'updated', 'user')
    search_fields = ('name',)
    ordering = ('name',)

@admin.register(ExamPattern)
class ExamPatternAdmin(BaseAdmin):
    list_display = ('name', 'total_marks', 'created', 'updated', 'user')
    search_fields = ('name',)
    ordering = ('name',)

@admin.register(Student)
class StudentAdmin(BaseAdmin):
    list_display = ('name', 'school_class', 'created', 'updated', 'user')
    search_fields = ('name', 'school_class__name')
    ordering = ('name',)

@admin.register(Enrollment)
class EnrollmentAdmin(BaseAdmin):
    list_display = ('student', 'school_class', 'created', 'updated', 'user')
    search_fields = ('student__name', 'school_class__name')
    ordering = ('student',)

@admin.register(FeeType)
class FeeTypeAdmin(BaseAdmin):
    list_display = ('name', 'created', 'updated', 'user')
    search_fields = ('name',)
    ordering = ('name',)

@admin.register(Fee)
class FeeAdmin(BaseAdmin):
    list_display = ('student', 'fee_type', 'amount', 'created', 'updated', 'user')
    search_fields = ('student__name', 'fee_type__name')
    ordering = ('student',)

@admin.register(Exam)
class ExamAdmin(BaseAdmin):
    list_display = ('school_class', 'subject', 'exam_pattern', 'created', 'updated', 'user')
    search_fields = ('subject__name', 'exam_pattern__name')
    ordering = ('school_class',)

@admin.register(Result)
class ResultAdmin(BaseAdmin):
    list_display = ('student', 'exam', 'marks_obtained', 'created', 'updated', 'user')
    search_fields = ('student__name', 'exam__subject__name')
    ordering = ('student',)
