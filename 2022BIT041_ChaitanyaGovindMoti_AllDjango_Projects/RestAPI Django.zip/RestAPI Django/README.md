# Book Management API

A Simple & Clean RESTful API built with Django REST Framework to manage book records.

## Features

- View all books
- Add a new book
- View a single book
- Update book details
- Delete a book

## Tech Stack

- Python
- Django
- Django REST Framework

## Setup Instructions

1. Create and activate a virtual environment:

```bash
python -m venv venv
# On Windows PowerShell
.\venv\Scripts\Activate.ps1
# On Windows CMD
venv\Scripts\activate.bat
# On Unix or MacOS
source venv/bin/activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run migrations:

```bash
python manage.py migrate
```

4. Run the development server:

```bash
python manage.py runserver
```

5. Access the API at `http://127.0.0.1:8000/api/books/`

## API Endpoints

- `GET /api/books/` - List all books
- `POST /api/books/` - Add a new book
- `GET /api/books/{id}/` - View a single book
- `PUT /api/books/{id}/` - Update book details
- `DELETE /api/books/{id}/` - Delete a book

## Notes

- Admin panel is available at `/admin/` (create superuser with `python manage.py createsuperuser`)
