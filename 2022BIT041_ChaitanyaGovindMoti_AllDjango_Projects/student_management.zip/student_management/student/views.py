from django.http import JsonResponse
from .models import Student

def get_student_data(request, registration_number):
    try:
        student = Student.objects.get(registration_number=registration_number)
        data = student.fetch_student_details()
        return JsonResponse({"status": "success", "data": data})
    except Student.DoesNotExist:
        return JsonResponse({"status": "error", "message": "Student not found"}, status=404)
