from django.db import models

# Student Base Model
class Student(models.Model):
    email = models.EmailField(primary_key=True)
    name = models.CharField(max_length=255)
    registration_number = models.CharField(max_length=20, unique=True)
    branch = models.CharField(max_length=100)
    year = models.IntegerField()
    mobile = models.CharField(max_length=15)
    address = models.TextField()
    photo = models.ImageField(upload_to='student_photos/', null=True, blank=True)
    date_of_birth = models.DateField()
    guardian_name = models.CharField(max_length=255)
    guardian_contact = models.CharField(max_length=15)

    def __str__(self):
        return self.name

    def fetch_student_details(self):
        """
        Fetch all relevant student details from different categories (hostel, bus, mess, fees, achievements, etc.)
        """
        return {
            "hostel": list(self.hostel_set.values()),
            "bus": list(self.busmanagement_set.values()),
            "mess": list(self.messmanagement_set.values()),
            "fees": list(self.studentfee_set.values()),
            "achievements": list(self.studentachievement_set.values()),
            "feedback": list(self.studentfeedback_set.values()),
            "leave": list(self.studentleave_set.values()),
        }

# Hostel Management Model
class Hostel(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    room_number = models.CharField(max_length=10)
    in_time = models.DateTimeField()
    out_time = models.DateTimeField(null=True, blank=True)  # Made optional
    status = models.CharField(max_length=10, choices=[('Present', 'Present'), ('Absent', 'Absent')], default='Present')

# Student Leave Management
class StudentLeave(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    leave_start_datetime = models.DateTimeField()
    leave_end_datetime = models.DateTimeField()
    reason = models.TextField()
    location = models.CharField(max_length=255)
    approval_status = models.CharField(
        max_length=10, 
        choices=[('Pending', 'Pending'), ('Approved', 'Approved'), ('Rejected', 'Rejected')], 
        default='Pending'
    )

# Student Fee Management
class StudentFee(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    fee_type = models.CharField(max_length=50, choices=[('Tuition', 'Tuition'), ('Hostel', 'Hostel'), ('Mess', 'Mess'), ('Bus', 'Bus')])
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_number = models.CharField(max_length=50, unique=True)
    transaction_mode = models.CharField(max_length=20, choices=[('UPI', 'UPI'), ('Card', 'Card'), ('Cash', 'Cash'), ('Bank Transfer', 'Bank Transfer')])
    transaction_date = models.DateField()
    payment_status = models.CharField(max_length=10, choices=[('Paid', 'Paid'), ('Pending', 'Pending')], default='Pending')

# Student Achievements
class StudentAchievement(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    event_date = models.DateField()
    event_name = models.CharField(max_length=255)
    event_organization = models.CharField(max_length=255)
    achievement_description = models.TextField()
    achievement_photos = models.ImageField(upload_to='achievements/')

# Bus Management
class BusManagement(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    bus_route = models.CharField(max_length=255)
    pickup_point = models.CharField(max_length=255)
    drop_point = models.CharField(max_length=255)
    payment_status = models.CharField(max_length=10, choices=[('Paid', 'Paid'), ('Pending', 'Pending')], default='Pending')

# Mess Management
class MessManagement(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    transaction_date = models.DateField(auto_now_add=True)
    payment_amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_mode = models.CharField(max_length=20, choices=[('UPI', 'UPI'), ('Card', 'Card'), ('Cash', 'Cash'), ('Bank Transfer', 'Bank Transfer')])

# Student Feedback
class StudentFeedback(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject_code = models.CharField(max_length=20)
    teacher_id = models.CharField(max_length=50)
    rating = models.IntegerField(choices=[(1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5')])
    feedback_text = models.TextField()
    submission_date = models.DateTimeField(auto_now_add=True)
