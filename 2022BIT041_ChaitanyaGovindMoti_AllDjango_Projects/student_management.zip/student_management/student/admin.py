from django.contrib import admin
from .models import *

#admin.site.register(Student)
admin.site.register(Hostel)
admin.site.register(StudentLeave)
#admin.site.register(StudentFee)
admin.site.register(StudentAchievement)
admin.site.register(BusManagement)
admin.site.register(MessManagement)
admin.site.register(StudentFeedback)

class StudentAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'registration_number', 'branch', 'year', 'mobile')
    search_fields = ('name', 'email', 'registration_number', 'branch')
    list_filter = ('year', 'branch')

class StudentFeeAdmin(admin.ModelAdmin):
    list_display = ('student', 'fee_type', 'amount', 'transaction_date', 'payment_status')
    search_fields = ('student__name', 'student__email', 'transaction_number')
    list_filter = ('fee_type', 'payment_status')

# Register with custom admin views
admin.site.register(Student, StudentAdmin)
admin.site.register(StudentFee, StudentFeeAdmin)