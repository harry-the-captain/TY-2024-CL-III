from django.urls import path
from .views import get_student_data

urlpatterns = [
    path('student/<str:registration_number>/', get_student_data, name='get_student_data'),
]
