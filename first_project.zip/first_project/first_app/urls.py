from django.urls import path
from . import views

urlpatterns = [
    path('record1/', views.record1_view, name='record1'),
]
