from django.http import HttpResponse

def record1_view(request):
    return HttpResponse("Hello, this is Record 1!")
